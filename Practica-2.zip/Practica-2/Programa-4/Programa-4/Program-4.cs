﻿using System;

namespace Programa_4
{
    class Program
    {
        static void Main(string[] args)
        {
            //4.Crea un programa que escriba en pantalla los números del 1 al 10, usando "do..while". 
            int i =1;

            do
            {
               
                Console.WriteLine(+i);
                i++;
            } while (i<= 10);
        }
    }
}
